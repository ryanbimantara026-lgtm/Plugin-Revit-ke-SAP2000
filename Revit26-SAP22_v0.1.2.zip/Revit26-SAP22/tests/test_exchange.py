import copy
import csv
import io
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import unittest
import zipfile
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'RevitToSAP.extension' / 'lib'))
from r2s.exchange import (HEADERS, JointIndex, build_model, csv_text, read_members,
                          rows_to_records, s2k_text, write_package)


def member(name, start, end, category='Beam'):
    row = {'Member': name, 'Category': category, 'Type': 'Beton 300x500',
           'Material': 'Beton, f\'c 30 MPa', 'RotationDeg': 0}
    for prefix, point in [('Start', start), ('End', end)]:
        row.update({prefix + axis: value for axis, value in zip('XYZ', point)})
    return row


def portal():
    return [member('C1', (0, 0, 0), (0, 0, 3), 'Column'),
            member('C2', (6, 0, 0), (6, 0, 3), 'Column'),
            member('B1', (0, 0, 3), (6, 0, 3))]


class ExchangeTests(unittest.TestCase):
    def test_portal_units_and_s2k_connectivity(self):
        for units, scale in [('m', 1), ('mm', 1000), ('cm', 100), ('ft', 1 / 0.3048)]:
            rows = portal()
            for row in rows:
                for header in HEADERS[1:7]:
                    row[header] *= scale
            model = build_model(rows, units)
            self.assertEqual((len(model['joints']), len(model['frames']), model['components']), (4, 3, 1))
            self.assertAlmostEqual(max(p[0] for p in model['joints']), 6)
            output = s2k_text(model)
            self.assertIn('Version=22.0.0', output)
            self.assertIn('CurrUnits="KN, m, C"', output)
            joint_ids = set(re.findall(r'\bJoint=(\d+)', output))
            refs = re.findall(r'\bJoint[IJ]=(\d+)', output)
            self.assertEqual(len(joint_ids), 4)
            self.assertTrue(set(refs) <= joint_ids)
            self.assertEqual(output.count('IsCurved=No'), 3)
            self.assertNotIn('FRAME SECTION ASSIGNMENTS', output)

    def test_merge_across_spatial_cell_boundary(self):
        index = JointIndex(0.001)
        self.assertEqual(index.add((0.00099, 0, 0)), index.add((0.00101, 0, 0)))
        # Euclidean tolerance, not a cube or rounded-coordinate equality.
        self.assertNotEqual(index.add((0.00099, 0, 0)), index.add((0.0018, 0.0008, 0)))

    def test_t_joint_split_preserves_original_source(self):
        rows = [member('C1', (0, 0, 0), (0, 0, 6), 'Column'),
                member('B1', (0, 0, 3), (6, 0, 3))]
        model = build_model(rows)
        self.assertEqual(len(model['joints']), 4)
        self.assertEqual(len(model['frames']), 3)
        self.assertEqual(model['split_count'], 1)
        self.assertEqual(model['components'], 1)
        self.assertEqual(sum(f['SourceMember'] == 'C1' for f in model['frames']), 2)
        self.assertEqual(len(build_model(rows, split=False)['frames']), 2)

    def test_crossing_without_endpoint_is_not_silently_joined(self):
        model = build_model([member('B1', (-1, 0, 0), (1, 0, 0)),
                             member('B2', (0, -1, 0), (0, 1, 0))])
        self.assertEqual((len(model['frames']), model['components']), (2, 2))

    def test_reject_invalid_geometry_and_ids(self):
        for rows in [[member('B1', (0, 0, 0), (0, 0, 0))],
                     [member('B1', (0, 0, 0), (float('nan'), 0, 0))],
                     [member('B1', (0, 0, 0), (float('inf'), 0, 0))],
                     [member('B1', (0, 0, 0), (1, 0, 0)), member('B1', (1, 0, 0), (2, 0, 0))],
                     [member('=1+2', (0, 0, 0), (1, 0, 0))],
                     [member('B1', (0, 0, 0), (1, 0, 0), 'Brace')]]:
            with self.assertRaises(ValueError):
                build_model(rows)
        for tol in [0, -1, float('nan')]:
            with self.assertRaises(ValueError):
                build_model(portal(), tolerance=tol)

    def test_reject_reverse_and_partial_overlap(self):
        with self.assertRaisesRegex(ValueError, 'tumpang tindih'):
            build_model([member('B1', (0, 0, 0), (6, 0, 0)),
                         member('B2', (6, 0, 0), (0, 0, 0))])
        with self.assertRaisesRegex(ValueError, 'tumpang tindih'):
            build_model([member('B1', (0, 0, 0), (6, 0, 0)),
                         member('B2', (3, 0, 0), (9, 0, 0))])

    def test_csv_tab_utf16_and_decimal_comma(self):
        with tempfile.TemporaryDirectory() as tmp:
            for delimiter, encoding in [(',', 'utf-8-sig'), (';', 'utf-8-sig'), ('\t', 'utf-16')]:
                stream = io.StringIO(newline='')
                writer = csv.writer(stream, delimiter=delimiter)
                writer.writerow(HEADERS)
                rows = portal()
                rows[0]['Family'] = 'Keluarga "A"\nLantai satu'
                for row in rows:
                    values = [row.get(h, '') for h in HEADERS]
                    if delimiter == ';':
                        values[6] = str(values[6]).replace('.', ',')
                    writer.writerow(values)
                path = Path(tmp) / 'members.txt'
                path.write_text(stream.getvalue(), encoding=encoding)
                parsed = read_members(str(path))
                self.assertIn('Lantai satu', parsed[0]['Family'])
                self.assertEqual(len(build_model(parsed)['frames']), 3)
            bad = Path(tmp) / 'bad.csv'
            bad.write_text('Wrong,Headers\n1,2', encoding='utf-8')
            with self.assertRaisesRegex(ValueError, 'Kolom wajib'):
                read_members(str(bad))

    def test_package_round_trip_does_not_overwrite(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = str(Path(tmp) / 'export')
            model = build_model(portal())
            write_package(model, folder)
            again = build_model(read_members(os.path.join(folder, 'members.csv')))
            self.assertEqual(s2k_text(model), s2k_text(again))
            with self.assertRaises(ValueError):
                write_package(model, folder)
            self.assertFalse(os.path.exists(os.path.join(folder, 'INCOMPLETE.txt')))
            self.assertIn('GEOMETRI SAJA', Path(folder, 'report.txt').read_text())

    def test_text_metadata_does_not_execute_in_excel(self):
        result = csv_text(['Name', 'X'], [['=1+2', -3]])
        parsed = list(csv.reader(io.StringIO(result)))
        self.assertEqual(parsed[1], ["'=1+2", '-3'])

    def test_xlsx_sample_and_formula_rejection(self):
        path = ROOT / 'examples' / 'Contoh_Excel_SAP22.xlsx'
        if not path.exists():
            self.skipTest('Contoh XLSX belum dibuat')
        model = build_model(read_members(str(path)))
        self.assertEqual((len(model['joints']), len(model['frames'])), (4, 3))
        with tempfile.TemporaryDirectory() as tmp:
            bad = Path(tmp) / 'formula.xlsx'
            with zipfile.ZipFile(path) as source, zipfile.ZipFile(bad, 'w') as target:
                for item in source.infolist():
                    content = source.read(item.filename)
                    if item.filename.startswith('xl/worksheets/sheet') and item.filename.endswith('.xml'):
                        root = ET.fromstring(content)
                        ns = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
                        cell = root.find('.//{' + ns + '}c')
                        ET.SubElement(cell, '{' + ns + '}f').text = '1+2'
                        content = ET.tostring(root, encoding='utf-8')
                    target.writestr(item, content)
            with self.assertRaisesRegex(ValueError, 'formula'):
                read_members(str(bad))

    def test_cli_export(self):
        with tempfile.TemporaryDirectory() as tmp:
            source = Path(tmp) / 'members.csv'
            source.write_text(csv_text(HEADERS, [[row.get(h, '') for h in HEADERS] for row in portal()]), encoding='utf-8')
            output = Path(tmp) / 'result'
            result = subprocess.run([sys.executable, str(ROOT / 'convert_to_s2k.py'), str(source),
                                     '--units', 'm', '--output', str(output)], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertTrue((output / 'model.s2k').exists())


if __name__ == '__main__':
    unittest.main()
