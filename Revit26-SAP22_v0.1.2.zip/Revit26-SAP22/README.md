# Revit 2026 → SAP2000 v22

Versi 0.1.0 · Balok dan kolom lurus · Ekstensi pyRevit

Paket ini mengekspor **garis model analitis balok dan kolom** dari proyek Revit 2026 menjadi S2K SAP2000 v22. Data juga disimpan sebagai CSV agar bisa dibuka dan diedit di Excel, lalu dikonversi kembali ke S2K. Konversi CSV/TXT/XLSX juga tersedia tanpa membuka Revit, menggunakan Python 3.

**Hasil S2K berisi geometri joint dan frame.** Profil, material, rotasi lokal, release, offset, tumpuan, beban, dan kombinasi belum dipindahkan sebagai pengaturan analisis. Nama family, type, material, dan rotasi Revit dicatat dalam CSV sebagai referensi. Tetapkan dan periksa properti tersebut di SAP2000 sebelum menjalankan analisis.

## 1. Pemasangan di Windows

1. Pasang [pyRevit dari rilis resmi](https://github.com/pyrevitlabs/pyRevit/releases) yang menyatakan dukungan untuk Revit 2026 dan pembaruan Revit yang kamu gunakan. Gunakan mesin IronPython bawaan pyRevit untuk ekstensi ini. Python terpisah tidak diperlukan untuk tombol di Revit.
2. Tutup Revit, kemudian ekstrak seluruh ZIP ini.
3. Tekan `Win + R`, masukkan `%APPDATA%\pyRevit\Extensions`, lalu tekan Enter. Buat folder tersebut jika belum ada.
4. Salin **folder `RevitToSAP.extension` beserta semua isinya** ke folder tersebut. Jangan menyalin hanya file `script.py`.
5. Buka Revit 2026. Tab **Revit to SAP** berisi tombol **Revit ke SAP22** dan **Excel CSV ke SAP22**.

Alternatif langkah 3–4: jalankan `install.ps1` pada komputer Windows kamu. Skrip hanya menyalin folder ekstensi ke profil pengguna dan berhenti jika versi sebelumnya sudah ada. Skrip tidak memasang pyRevit.

Jika tombol belum muncul, pastikan pyRevit terpasang pada Revit 2026 dan folder ekstensi tercantum di pengaturan pencarian ekstensi pyRevit. Muat ulang pyRevit atau jalankan ulang Revit. Untuk menghapus plugin, tutup Revit lalu pindahkan/hapus hanya folder `RevitToSAP.extension` yang tadi disalin.

## 2. Ekspor langsung dari Revit ke S2K

1. Buka proyek `.rvt` di Revit 2026.
2. Siapkan **Analytical Model** untuk balok dan kolom. Pada Revit versi ini, model analitis merupakan elemen tersendiri. Periksa garis sumbu, konektivitas, peran Beam/Column, dan asosiasi ke elemen fisik.
3. Pilih balok/kolom yang ingin dipindahkan, atau kosongkan pilihan untuk seluruh model. Plugin membaca model utama; model Revit yang ditautkan tidak ikut diekspor.
4. Klik **Revit to SAP → Revit ke SAP22**. Jika ada pilihan elemen, tentukan apakah memakai pilihan atau seluruh model.
5. Jika terdapat elemen terlewat, dialog menunjukkan jumlahnya. Kamu bisa membatalkan untuk memperbaiki model, atau melanjutkan ekspor parsial. Rinciannya masuk ke `report.txt`.
6. Masukkan toleransi penggabungan ujung. Nilai awal **1 mm**. Dua titik berjarak sampai toleransi ini memakai joint yang sama. Koordinat joint pertama dipertahankan; perubahan jarak dilaporkan.
7. Pilih **Potong pada joint segaris** bila balok bertemu di tengah kolom atau frame lain. Frame dibagi hanya pada joint yang tepat berada pada garisnya. Pilihan **Sambungkan ujung saja** mempertahankan frame utuh.
8. Pilih folder induk. Plugin membuat folder hasil baru, sehingga ekspor lama tetap tersedia.

Plugin membaca dokumen tanpa transaksi dan tidak menyimpan perubahan pada model Revit. Member melengkung dan elemen di luar lingkup dilewati, bukan diubah menjadi garis perkiraan. Balok/kolom fisik yang belum mempunyai model analitis tidak ditebak sumbunya dari bentuk solid.

## 3. Baca hasil di SAP2000 v22

1. Buka SAP2000 v22.
2. Pilih **File → Import → SAP2000 .s2k Text File**.
3. Pilih `model.s2k` dalam folder hasil.
4. Untuk percobaan pertama, impor sebagai **model baru**. Periksa log impor, jumlah joint/frame, dimensi bentang, dan tinggi.
5. Periksa konektivitas dan orientasi model. Tetapkan profil, material, sumbu lokal, release, offset, tumpuan, beban, serta kombinasi sesuai model struktur kamu.

Satuan file adalah **KN, m, C**. Koordinat Revit dikonversi dari satuan internal ke meter. Koordinat memakai **internal origin Revit**, dengan global Z ke atas; shared coordinates dan transformasi model link tidak diterapkan.

Mulai dengan contoh portal di folder `examples`: 2 kolom, 1 balok, 4 joint, bentang 6 m, tinggi 3 m. Ini data sintetis untuk memeriksa alur impor, tanpa properti analisis.

## 4. Revit → CSV → Excel → S2K

1. Ekspor dari Revit. Buka `members.csv` di Excel melalui **Data → From Text/CSV** dan pilih UTF-8. Pilih koma sebagai delimiter untuk CSV hasil plugin.
2. Edit koordinat atau metadata yang diperlukan. Pertahankan header pada baris 1. Tambahkan member sebagai baris baru dengan ID unik.
3. Simpan sebagai **XLSX**, dengan sheet data bernama **Members**, atau **CSV UTF-8**. File TXT tab-delimited UTF-16 dari Excel juga diterima.
4. Jika menggunakan formula, ubah hasilnya menjadi nilai dengan **Copy → Paste Values**. Pembaca XLSX sengaja menolak formula agar tidak memakai cache hasil yang sudah lama.
5. Di Revit, klik **Excel CSV ke SAP22**. Pilih file, satuan koordinat sumber, toleransi, dan opsi sambungan. Pilih folder induk hasil.
6. Impor `model.s2k` ke SAP2000 seperti langkah sebelumnya.

Contoh workbook tersedia di `examples/Contoh_Excel_SAP22.xlsx`. Sheet **Members** berisi data yang dapat dikonversi; sheet **Panduan** menjelaskan kolom dan satuan. Format `.xls` lama tidak didukung; simpan ulang sebagai `.xlsx` atau CSV.

### Kolom data

| Kolom | Isi |
| --- | --- |
| Member | ID unik 1–48 karakter: huruf/angka ASCII, titik, tanda minus, garis bawah. Contoh `B1`, `C1`, `R12345`. |
| StartX, StartY, StartZ | Koordinat ujung awal dalam satu satuan yang sama. |
| EndX, EndY, EndZ | Koordinat ujung akhir dalam satu satuan yang sama. |
| Category | Opsional: `Beam`/`Balok` atau `Column`/`Kolom`. |
| RevitId, PhysicalId | Opsional: ID model analitis dan elemen fisik Revit. |
| Family, Type, Material | Opsional: informasi profil/material untuk pemeriksaan. |
| RotationDeg | Opsional: sudut penampang dari Revit dalam derajat. Referensi saja; tidak di-assign ke SAP. |

Konverter menerima koma, titik koma, atau tab sebagai pemisah kolom. Gunakan titik desimal untuk file berkoma. Koma desimal juga diterima pada file bertitik koma/tab. **Jangan gunakan pemisah ribuan** dalam koordinat. CSV/TXT harus UTF-8, atau UTF-16 dengan BOM.

## 5. File dalam setiap hasil ekspor

| File | Kegunaan |
| --- | --- |
| model.s2k | Geometri yang akan diimpor ke SAP2000 v22. |
| members.csv | Data sumbu member dan metadata. Semua koordinat hasil selalu meter. Ini input untuk konversi ulang. |
| joints.csv | Daftar joint yang sudah digabung, dengan koordinat meter. |
| frames.csv | Koneksi JointI–JointJ dan pemetaan frame ke SourceMember. |
| report.txt | Jumlah objek, penggabungan titik, frame yang dibagi, dan elemen terlewat. |
| manifest.json | Ringkasan satuan, target, dan cakupan untuk pengolahan lanjutan. |

Frame SAP diberi nomor unik. Gunakan `frames.csv` untuk menelusurinya ke ID member dan `members.csv` untuk menelusuri elemen Revit. Jika satu member dibagi pada sambungan, beberapa frame menunjuk SourceMember yang sama.

## 6. Konverter tanpa membuka Revit

Opsional: pasang Python 3, lalu buka terminal dalam folder paket dan jalankan:

```text
py convert_to_s2k.py examples\Contoh_Excel_SAP22.xlsx --units m --output hasil_sap22
```

Untuk file dengan koordinat milimeter:

```text
py convert_to_s2k.py members.csv --units mm --tolerance-mm 1 --output hasil_sap22_mm
```

Folder hasil harus belum ada. Tambahkan `--no-split` jika hanya ingin menggabungkan ujung. Konverter tidak memerlukan paket Python tambahan atau Excel terpasang.

## 7. Pemeriksaan dan batas versi ini

- Ekspor balok dan kolom **lurus** dari AnalyticalMember. Pelat, dinding, bracing, bukaan, link Revit, dan kurva berada di luar lingkup.
- Panjang member harus melebihi dua kali toleransi. ID duplikat, koordinat tidak valid, dan segmen tumpang tindih setelah pembagian frame ditolak.
- Persilangan dua garis tanpa endpoint pada persilangan tidak otomatis dijadikan sambungan. Periksa atau tambahkan joint yang diperlukan pada model sumber.
- Joint yang nyaris berada di tengah frame tidak ditarik ke garis frame. Pembagian memakai uji segaris ketat, sekitar 0.00001 mm, agar tidak membengkokkan frame. Cek sambungan yang nyaris berimpit di SAP2000.
- Jumlah kelompok geometri terhubung dicatat. Lebih dari satu kelompok memerlukan pemeriksaan sambungan.
- Saat ekspor seluruh model, pengumpul membaca semua AnalyticalMember yang memenuhi syarat dalam dokumen, termasuk yang mungkin tersembunyi dalam tampilan. Gunakan pilihan elemen untuk membatasi cakupan, fase, atau alternatif desain.
- Tabel S2K menggunakan target versi 22.0.0 dan hanya memuat Program Control, Joint Coordinates, dan Connectivity - Frame.
- Konverter dan data contoh diuji secara otomatis. **Plugin belum dijalankan langsung di Revit 2026, dan hasil belum diimpor langsung ke SAP2000 v22 di lingkungan pembuat paket ini.** Lakukan uji portal contoh dan periksa log impor sebelum memakai model proyek.

Jalankan pengujian konverter dengan `py -m unittest discover -s tests -v` dari folder paket.

## Referensi pengembangan

- [Dokumentasi resmi CSI: impor S2K](https://docs.csiamerica.com/help-files/sap/Menus/File/Import/Import_SAP2000_V8_to_11_s2k_Text_File.htm)
- [CSI: impor koordinat CSV/TXT melalui tabel dan Excel](https://web.wiki.csiamerica.com/wiki/spaces/kb/pages/2002086)
- [Autodesk: model analitis dan API AnalyticalMember](https://help.autodesk.com/cloudhelp/2023/ENU/Revit-Analyze/files/GUID-A1157199-4E27-41F9-BF45-53A5CD79E9A1.htm)
- [Autodesk Revit 2026: asosiasi model analitis dan fisik](https://help.autodesk.com/cloudhelp/2026/ENU/Revit-API-MainReference/files/html/0f7f395b-3f70-aa6e-e584-b70c11f767ad.htm)
- [pyRevit: dukungan Revit 2026](https://pyrevitlabs.io/posts/revit-2026-support---pre-release/)
- [pyRevit: struktur ekstensi](https://docs.pyrevitlabs.io/reference/pyrevit/extensions/)
