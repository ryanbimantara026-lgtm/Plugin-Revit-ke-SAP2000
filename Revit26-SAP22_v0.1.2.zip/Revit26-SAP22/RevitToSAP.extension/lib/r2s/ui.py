# -*- coding: utf-8 -*-
from __future__ import division, unicode_literals
import datetime
import os
import traceback
from pyrevit import forms, revit, script
from r2s.exchange import build_model, read_members, write_package, number, text


def settings():
    value = forms.ask_for_string(default="1", prompt="Toleransi penggabungan ujung (mm). Default 1 mm.",
                                 title="Revit to SAP2000 v22")
    if value is None:
        script.exit()
    tolerance = number(value, "Toleransi mm") / 1000
    mode = forms.CommandSwitchWindow.show(
        ["Potong pada joint segaris", "Sambungkan ujung saja"],
        message="Sambungan balok/kolom. Persilangan tanpa joint tidak dipotong.")
    if not mode:
        script.exit()
    return tolerance, mode == "Potong pada joint segaris"


def export_folder(prefix):
    root = forms.pick_folder(title="Pilih folder induk hasil ekspor")
    if not root:
        script.exit()
    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    return os.path.join(root, prefix + "_" + stamp)


def finish(model, folder, notes):
    write_package(model, folder, notes)
    forms.alert("Selesai: {} member, {} joint, {} frame.\n\n{}\n\n"
                "Impor model.s2k melalui File > Import > SAP2000 .s2k Text File.\n"
                "Hasil berisi geometri. Tetapkan profil, material, tumpuan dan beban di SAP2000.\n"
                "Baca report.txt untuk elemen terlewat dan sambungan terpisah.".format(
                    len(model["members"]), len(model["joints"]), len(model["frames"]), folder),
                title="Revit to SAP2000 v22")


def run_export():
    try:
        doc = revit.doc
        if doc is None or doc.IsFamilyDocument:
            forms.alert("Buka model proyek Revit 2026 terlebih dahulu.", exitscript=True)
        if text(doc.Application.VersionNumber) != "2026":
            forms.alert("Ekstensi ini ditargetkan untuk Revit 2026.", exitscript=True)
        from r2s.revit_export import collect_members, element_id
        selection = set(element_id(eid) for eid in revit.uidoc.Selection.GetElementIds())
        if selection:
            scope = forms.CommandSwitchWindow.show(
                ["Elemen terpilih", "Seluruh model"], message="Lingkup balok dan kolom")
            if not scope:
                script.exit()
            if scope == "Seluruh model":
                selection = set()
        records, notes, skipped, missing = collect_members(doc, selection)
        if not records:
            forms.alert("Tidak ada garis analitis balok/kolom lurus yang bisa diekspor.\n"
                        "Siapkan Analytical Model di Revit dan pastikan peran Beam/Column serta "
                        "asosiasi ke elemen fisik benar.\n\n" + "\n".join(notes[:8]), exitscript=True)
        if skipped or missing:
            proceed = forms.alert(
                "Terdapat {} member analitis yang dilewati dan {} balok/kolom fisik tanpa hasil "
                "terkait.\n\nEkspor yang tersedia: {} member. Detail akan dicatat di report.txt.\n"
                "Lanjutkan ekspor parsial?".format(skipped, len(missing), len(records)),
                title="Periksa cakupan ekspor", yes=True, no=True, ok=False)
            if not proceed:
                script.exit()
        tolerance, split = settings()
        model = build_model(records, units="m", tolerance=tolerance, split=split)
        folder = export_folder("Revit26_SAP22")
        finish(model, folder, notes)
    except Exception as error:
        script.get_logger().error(traceback.format_exc())
        forms.alert("Ekspor gagal:\n" + text(error), title="Revit to SAP2000 v22")


def run_convert():
    try:
        path = forms.pick_file(files_filter="Data struktur (*.csv;*.txt;*.xlsx)|*.csv;*.txt;*.xlsx",
                               title="Pilih members.csv, TXT, atau workbook Excel")
        if not path:
            script.exit()
        units = forms.CommandSwitchWindow.show(
            ["m", "mm", "cm", "ft"], message="Satuan koordinat dalam file input")
        if not units:
            script.exit()
        tolerance, split = settings()
        records = read_members(path)
        model = build_model(records, units=units, tolerance=tolerance, split=split)
        folder = export_folder("Excel_SAP22")
        finish(model, folder, ["Sumber konversi: " + os.path.basename(path)])
    except Exception as error:
        script.get_logger().error(traceback.format_exc())
        forms.alert("Konversi gagal:\n" + text(error), title="Excel to SAP2000 v22")
