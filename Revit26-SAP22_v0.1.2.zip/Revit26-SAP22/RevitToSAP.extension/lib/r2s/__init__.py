# -*- coding: utf-8 -*-
"""RevitToSAP 0.1.0. Shared by IronPython/pyRevit and Python 3."""
__version__ = "0.1.0"
