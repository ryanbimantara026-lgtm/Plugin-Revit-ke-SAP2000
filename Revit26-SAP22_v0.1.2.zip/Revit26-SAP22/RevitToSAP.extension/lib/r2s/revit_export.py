# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import math
from Autodesk.Revit import DB
from Autodesk.Revit.DB.Structure import (
    AnalyticalMember, AnalyticalToPhysicalAssociationManager, StructuralType)
from r2s.exchange import text


def element_id(value):
    return int(value.Value)


def element_name(element):
    if element is None:
        return ""
    return text(DB.Element.Name.GetValue(element))


def physical_kind(element):
    if not isinstance(element, DB.FamilyInstance):
        return None
    if element.StructuralType == StructuralType.Column:
        return "Column"
    if element.StructuralType == StructuralType.Beam:
        return "Beam"
    return None


def _level_z(doc, phys, level_bip, offset_bip):
    """Elevasi (satuan internal) = elevasi level + offset; None jika level tidak ada."""
    lp = phys.get_Parameter(level_bip)
    if lp is None or not lp.HasValue:
        return None
    level = doc.GetElement(lp.AsElementId())
    if level is None:
        return None
    off = phys.get_Parameter(offset_bip)
    return level.Elevation + (off.AsDouble() if off is not None and off.HasValue else 0.0)


def _physical_points(doc, phys, kind):
    """Dua titik ujung (internal units) dari location line elemen fisik, atau None."""
    loc = phys.Location
    if isinstance(loc, DB.LocationCurve):
        c = loc.Curve
        if isinstance(c, DB.Line) and c.IsBound:
            return c.GetEndPoint(0), c.GetEndPoint(1)
        return None
    if isinstance(loc, DB.LocationPoint) and kind == "Column":
        z0 = _level_z(doc, phys, DB.BuiltInParameter.FAMILY_BASE_LEVEL_PARAM,
                      DB.BuiltInParameter.FAMILY_BASE_LEVEL_OFFSET_PARAM)
        z1 = _level_z(doc, phys, DB.BuiltInParameter.FAMILY_TOP_LEVEL_PARAM,
                      DB.BuiltInParameter.FAMILY_TOP_LEVEL_OFFSET_PARAM)
        if z0 is None or z1 is None or abs(z1 - z0) < 1e-6:
            return None
        p = loc.Point
        return DB.XYZ(p.X, p.Y, z0), DB.XYZ(p.X, p.Y, z1)
    return None


def _physical_row(doc, phys, kind):
    """Baris export dari elemen fisik (cadangan bila AnalyticalMember tidak ada)."""
    pts = _physical_points(doc, phys, kind)
    if pts is None:
        return None
    pid = element_id(phys.Id)
    section = doc.GetElement(phys.GetTypeId())
    material = None
    parameter = phys.get_Parameter(DB.BuiltInParameter.STRUCTURAL_MATERIAL_PARAM)
    if parameter and parameter.StorageType == DB.StorageType.ElementId:
        material = doc.GetElement(parameter.AsElementId())
    family = element_name(section.Family) if isinstance(section, DB.FamilySymbol) else ""
    row = {"Member": "P" + text(pid), "Category": kind, "RevitId": text(pid),
           "PhysicalId": text(pid), "Family": family, "Type": element_name(section),
           "Material": element_name(material), "RotationDeg": 0.0}
    for prefix, p in zip(("Start", "End"), pts):
        for axis, v in zip("XYZ", (p.X, p.Y, p.Z)):
            row[prefix + axis] = DB.UnitUtils.ConvertFromInternalUnits(v, DB.UnitTypeId.Meters)
    return row


def collect_members(doc, selected_ids=None, fallback=True):
    """Read analytical axes, without starting a Revit transaction."""
    manager = AnalyticalToPhysicalAssociationManager.GetAnalyticalToPhysicalAssociationManager(doc)
    analytical = sorted(list(DB.FilteredElementCollector(doc).OfClass(AnalyticalMember)),
                        key=lambda e: element_id(e.Id))
    physical = {}
    for category in (DB.BuiltInCategory.OST_StructuralColumns,
                     DB.BuiltInCategory.OST_StructuralFraming):
        for element in DB.FilteredElementCollector(doc).OfCategory(category).WhereElementIsNotElementType():
            if physical_kind(element):
                physical[element_id(element.Id)] = element
    selected_ids = set(selected_ids or [])
    records, notes, covered = [], [], set()
    skipped, ignored = 0, 0
    for member in analytical:
        mid = element_id(member.Id)
        try:
            associated = []
            if manager:
                if hasattr(manager, "GetAssociatedElementIds"):
                    associated = list(manager.GetAssociatedElementIds(member.Id))
                else:
                    eid = manager.GetAssociatedElementId(member.Id)
                    if eid != DB.ElementId.InvalidElementId:
                        associated = [eid]
            associated_ids = set(element_id(eid) for eid in associated)
            if selected_ids and mid not in selected_ids and not (associated_ids & selected_ids):
                continue
            eligible = [physical[pid] for pid in sorted(associated_ids) if pid in physical]
            role = text(member.StructuralRole)
            kind = "Column" if role.endswith("Column") else "Beam" if role.endswith("Beam") else None
            if len(eligible) > 1:
                skipped += 1
                notes.append("LEWATI R{}: terasosiasi ke beberapa elemen fisik; periksa pemetaan.".format(mid))
                continue
            phys = eligible[0] if eligible else None
            if phys is not None:
                kind = physical_kind(phys)
            elif associated_ids:
                # An analytical member linked to a brace or another category is out of scope.
                ignored += 1
                continue
            if kind is None:
                ignored += 1
                continue
            curve = member.GetCurve()
            if not isinstance(curve, DB.Line) or not curve.IsBound:
                skipped += 1
                notes.append("LEWATI R{}: hanya garis lurus terikat yang didukung.".format(mid))
                continue
            points = [curve.GetEndPoint(i) for i in (0, 1)]
            coords = [[DB.UnitUtils.ConvertFromInternalUnits(v, DB.UnitTypeId.Meters)
                       for v in (p.X, p.Y, p.Z)] for p in points]
            section = doc.GetElement(member.SectionType)
            if section is None and phys is not None:
                section = doc.GetElement(phys.GetTypeId())
            material = doc.GetElement(member.MaterialId)
            if material is None and phys is not None:
                parameter = phys.get_Parameter(DB.BuiltInParameter.STRUCTURAL_MATERIAL_PARAM)
                if parameter and parameter.StorageType == DB.StorageType.ElementId:
                    material = doc.GetElement(parameter.AsElementId())
            family = ""
            if isinstance(section, DB.FamilySymbol):
                family = element_name(section.Family)
            row = {"Member": "R" + text(mid), "Category": kind, "RevitId": text(mid),
                   "PhysicalId": text(element_id(phys.Id)) if phys is not None else "",
                   "Family": family, "Type": element_name(section),
                   "Material": element_name(material),
                   "RotationDeg": member.CrossSectionRotation * 180.0 / math.pi}
            for prefix, point in zip(("Start", "End"), coords):
                for axis, value in zip("XYZ", point):
                    row[prefix + axis] = value
            records.append(row)
            if phys is not None:
                covered.add(element_id(phys.Id))
        except Exception as error:
            skipped += 1
            notes.append("LEWATI R{}: {}".format(mid, text(error)))
    # CADANGAN: elemen fisik tanpa AnalyticalMember dibaca dari location line-nya.
    fallback_used = 0
    if fallback:
        for pid in sorted(set(physical) - covered):
            if selected_ids and pid not in selected_ids:
                continue
            phys = physical[pid]
            try:
                row = _physical_row(doc, phys, physical_kind(phys))
            except Exception as error:
                row = None
                notes.append("LEWATI P{}: {}".format(pid, text(error)))
            if row is None:
                skipped += 1
                notes.append("LEWATI P{}: location line tidak lurus/tidak lengkap.".format(pid))
                continue
            records.append(row)
            covered.add(pid)
            fallback_used += 1
        if fallback_used:
            notes.append("CADANGAN: {} elemen memakai location line fisik (bukan AnalyticalMember); "
                         "offset justifikasi & rotasi penampang TIDAK diperhitungkan. "
                         "Aktifkan Analytical Model untuk hasil akurat.".format(fallback_used))
    expected = set(physical) & selected_ids if selected_ids else set(physical)
    missing = sorted(expected - covered)
    notes.insert(0, "Koordinat: Revit internal origin, tanpa transformasi shared coordinates.")
    notes.insert(1, "AnalyticalMember di dokumen: {} | dalam lingkup diekspor: {} | gagal/dilewati: {} | peran lain: {}".format(
        len(analytical), len(records), skipped, ignored))
    notes.append("Balok/kolom fisik tanpa hasil ekspor terasosiasi: {}".format(len(missing)))
    if missing:
        notes.append("PhysicalId belum tercakup: " + ", ".join(text(i) for i in missing))
    return records, notes, skipped, missing
