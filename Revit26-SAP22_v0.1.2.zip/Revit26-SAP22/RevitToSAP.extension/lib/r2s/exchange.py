# -*- coding: utf-8 -*-
from __future__ import division, unicode_literals

import csv
import io
import json
import math
import os
import posixpath
import re
import sys
import zipfile
import xml.etree.ElementTree as ET
from collections import defaultdict

try:
    text_type = unicode
except NameError:
    text_type = str

HEADERS = ["Member", "StartX", "StartY", "StartZ", "EndX", "EndY", "EndZ",
           "Category", "RevitId", "PhysicalId", "Family", "Type", "Material",
           "RotationDeg"]
SCALES = {"m": 1.0, "mm": 0.001, "cm": 0.01, "ft": 0.3048}
NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}


def text(value):
    return "" if value is None else text_type(value)


def number(value, context):
    raw = text(value).strip()
    # Decimal commas allowed for semicolon/tab input. Thousands separators are not.
    if "," in raw and "." not in raw:
        raw = raw.replace(",", ".")
    try:
        result = float(raw)
    except (ValueError, TypeError):
        raise ValueError("{}: angka tidak valid: {!r}".format(context, value))
    if math.isnan(result) or math.isinf(result):
        raise ValueError("{}: angka harus finite".format(context))
    return result


def read_delimited(path):
    with io.open(path, "rb") as stream:
        raw = stream.read()
    encoding = "utf-16" if raw.startswith((b"\xff\xfe", b"\xfe\xff")) else "utf-8-sig"
    content = raw.decode(encoding)
    if not content.strip():
        raise ValueError("File kosong")
    first = content.splitlines()[0]
    delimiter = max([",", ";", "\t"], key=lambda d: first.count(d))
    if sys.version_info[0] < 3:
        rows = [[v.decode("utf-8") for v in row] for row in
                csv.reader([line.encode("utf-8") for line in content.splitlines(True)],
                           delimiter=str(delimiter))]
    else:
        rows = list(csv.reader(io.StringIO(content), delimiter=delimiter))
    return rows_to_records(rows)


def rows_to_records(rows):
    if not rows:
        raise ValueError("Tabel kosong")
    headers = [text(v).strip() for v in rows[0]]
    if len(headers) != len(set(headers)):
        raise ValueError("Nama kolom duplikat")
    missing = [h for h in HEADERS[:7] if h not in headers]
    if missing:
        raise ValueError("Kolom wajib tidak ditemukan: " + ", ".join(missing))
    records = []
    for rownum, row in enumerate(rows[1:], 2):
        if not any(text(v).strip() for v in row):
            continue
        if len(row) > len(headers) and any(text(v).strip() for v in row[len(headers):]):
            raise ValueError("Baris {}: terlalu banyak kolom; cek pemisah/desimal".format(rownum))
        record = dict(zip(headers, list(row) + [""] * max(0, len(headers) - len(row))))
        record["_row"] = rownum
        records.append(record)
    if not records:
        raise ValueError("Tidak ada baris member")
    return records


def read_xlsx(path):
    """Read values only from Members. No Excel installation or macros needed."""
    with zipfile.ZipFile(path) as archive:
        # A small input workbook should not expand to hundreds of MB.
        if sum(item.file_size for item in archive.infolist()) > 100 * 1024 * 1024:
            raise ValueError("Workbook terlalu besar (maksimum XML 100 MB)")
        workbook = ET.fromstring(archive.read("xl/workbook.xml"))
        rels = ET.fromstring(archive.read("xl/_rels/workbook.xml.rels"))
        targets = dict((r.attrib["Id"], r.attrib["Target"]) for r in rels)
        target = None
        for sheet in workbook.findall("m:sheets/m:sheet", NS):
            if sheet.attrib["name"].lower() == "members":
                rid = sheet.attrib["{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"]
                target = targets[rid]
        if target is None:
            raise ValueError("Workbook harus mempunyai sheet bernama Members")
        target = target.lstrip("/") if target.startswith("/") else posixpath.normpath("xl/" + target)
        shared = []
        if "xl/sharedStrings.xml" in archive.namelist():
            root = ET.fromstring(archive.read("xl/sharedStrings.xml"))
            shared = ["".join(t.text or "" for t in si.iter("{" + NS["m"] + "}t"))
                      for si in root]
        root = ET.fromstring(archive.read(target))
        rows = []
        for row in root.findall("m:sheetData/m:row", NS):
            values = {}
            for cell in row.findall("m:c", NS):
                address = cell.attrib.get("r", "")
                letters = re.match(r"[A-Z]+", address)
                if not letters:
                    raise ValueError("Alamat sel XLSX tidak valid")
                index = 0
                for char in letters.group(0):
                    index = index * 26 + ord(char) - 64
                if index > 256:
                    continue
                if cell.find("m:f", NS) is not None:
                    raise ValueError("Sel {} berisi formula. Copy > Paste Values sebelum konversi".format(address))
                kind = cell.attrib.get("t", "")
                node = cell.find("m:v", NS)
                value = node.text if node is not None else ""
                if kind == "s":
                    value = shared[int(value)]
                elif kind == "inlineStr":
                    value = "".join(t.text or "" for t in cell.iter("{" + NS["m"] + "}t"))
                elif kind == "e":
                    raise ValueError("Sel {} berisi error Excel".format(address))
                values[index - 1] = value
            if values:
                rows.append([values.get(i, "") for i in range(max(values) + 1)])
        return rows_to_records(rows)


def read_members(path):
    return read_xlsx(path) if path.lower().endswith(".xlsx") else read_delimited(path)


def distance(a, b):
    return math.sqrt(sum((x - y) ** 2 for x, y in zip(a, b)))


class JointIndex(object):
    def __init__(self, tolerance):
        self.tolerance = tolerance
        self.points = []
        self.cells = defaultdict(list)
        self.snaps = []

    def add(self, point):
        cell = tuple(int(math.floor(v / self.tolerance)) for v in point)
        candidates = []
        for x in (-1, 0, 1):
            for y in (-1, 0, 1):
                for z in (-1, 0, 1):
                    key = (cell[0] + x, cell[1] + y, cell[2] + z)
                    for idx in self.cells.get(key, []):
                        delta = distance(point, self.points[idx])
                        if delta <= self.tolerance:
                            candidates.append((delta, idx))
        if candidates:
            delta, idx = min(candidates)
            if delta > 1e-10:
                self.snaps.append(delta)
            return idx
        idx = len(self.points)
        self.points.append(tuple(point))
        self.cells[cell].append(idx)
        return idx


def build_model(records, units="m", tolerance=0.001, split=True):
    if units not in SCALES:
        raise ValueError("Satuan harus m, mm, cm, atau ft")
    tolerance = number(tolerance, "Toleransi")
    if not 1e-8 <= tolerance <= 0.1:
        raise ValueError("Toleransi harus 0.00001 sampai 100 mm")
    scale = SCALES[units]
    index = JointIndex(tolerance)
    members, seen = [], set()
    for record in records:
        row = record.get("_row", "?")
        name = text(record.get("Member", "")).strip()
        if not re.match(r"^[A-Za-z0-9_.-]{1,48}$", name):
            raise ValueError("Baris {}: Member wajib unik, 1-48 huruf/angka ASCII, _, -, atau titik".format(row))
        if name in seen:
            raise ValueError("Member duplikat: " + name)
        seen.add(name)
        category = text(record.get("Category", "")).strip()
        if category and category.lower() not in ("beam", "column", "balok", "kolom"):
            raise ValueError("{}: Category hanya Beam/Column atau Balok/Kolom".format(name))
        points = [tuple(number(record.get(prefix + axis, ""), name + "." + prefix + axis) * scale
                        for axis in "XYZ") for prefix in ("Start", "End")]
        if distance(*points) <= 2 * tolerance:
            raise ValueError("{}: panjang <= 2 x toleransi. Perbaiki geometri/toleransi".format(name))
        member = dict((h, record.get(h, "")) for h in HEADERS)
        member["Member"] = name
        if text(member.get("RotationDeg", "")).strip():
            number(member["RotationDeg"], name + ".RotationDeg")
        for prefix, point in zip(("Start", "End"), points):
            for axis, value in zip("XYZ", point):
                member[prefix + axis] = value
        member["_i"], member["_j"] = [index.add(p) for p in points]
        if member["_i"] == member["_j"]:
            raise ValueError(name + ": ujung menyatu setelah snapping")
        members.append(member)
    if not members:
        raise ValueError("Tidak ada balok/kolom untuk diekspor")
    frames, edges, split_count = [], {}, 0
    for member in members:
        i, j = member["_i"], member["_j"]
        a, b = index.points[i], index.points[j]
        vector = tuple(y - x for x, y in zip(a, b))
        length2 = sum(v * v for v in vector)
        cuts = [(0.0, i), (1.0, j)]
        if split:
            for k, p in enumerate(index.points):
                if k in (i, j) or any(p[d] < min(a[d], b[d]) - tolerance or
                                      p[d] > max(a[d], b[d]) + tolerance for d in range(3)):
                    continue
                t = sum((p[d] - a[d]) * vector[d] for d in range(3)) / length2
                if 0 < t < 1:
                    projection = tuple(a[d] + t * vector[d] for d in range(3))
                    # Splitting must not introduce a kink by moving a joint off its own line.
                    if distance(p, projection) <= 1e-8:
                        cuts.append((t, k))
        cuts.sort()
        split_count += len(cuts) - 2
        for seq in range(len(cuts) - 1):
            ni, nj = cuts[seq][1], cuts[seq + 1][1]
            if distance(index.points[ni], index.points[nj]) <= tolerance:
                raise ValueError(member["Member"] + ": segmen hasil split terlalu pendek")
            edge = tuple(sorted((ni, nj)))
            if edge in edges:
                raise ValueError("Frame tumpang tindih: {} dan {}".format(edges[edge], member["Member"]))
            edges[edge] = member["Member"]
            # Independent numeric frame labels avoid member/segment name collisions.
            frames.append({"Frame": text(len(frames) + 1), "JointI": text(ni + 1),
                           "JointJ": text(nj + 1), "SourceMember": member["Member"],
                           "Segment": seq + 1})
    adjacency = defaultdict(set)
    for a, b in edges:
        adjacency[a].add(b)
        adjacency[b].add(a)
    pending, components = set(adjacency), 0
    while pending:
        components += 1
        stack = [pending.pop()]
        while stack:
            for other in adjacency[stack.pop()]:
                if other in pending:
                    pending.remove(other)
                    stack.append(other)
    return {"members": members, "joints": index.points, "frames": frames,
            "tolerance_m": tolerance, "split_count": split_count,
            "snaps": index.snaps, "components": components,
            "input_units": units, "split": split}


def fmt(value):
    # float() wajib: IronPython menolak presisi pada int ("Precision not allowed in integer format specifier")
    return "{:.12g}".format(float(value))


def s2k_text(model):
    # Deliberately contains geometry only. No invented materials, supports or loads.
    lines = ['TABLE:  "PROGRAM CONTROL"',
             '   ProgramName=SAP2000   Version=22.0.0   CurrUnits="KN, m, C"', "",
             'TABLE:  "JOINT COORDINATES"']
    for i, point in enumerate(model["joints"], 1):
        lines.append('   Joint={}   CoordSys=GLOBAL   CoordType=Cartesian   XorR={}   Y={}   Z={}'.format(
            i, *[fmt(v) for v in point]))
    lines.extend(["", 'TABLE:  "CONNECTIVITY - FRAME"'])
    for frame in model["frames"]:
        lines.append('   Frame={Frame}   JointI={JointI}   JointJ={JointJ}   IsCurved=No'.format(**frame))
    lines.extend(["", "END TABLE DATA", ""])
    return "\r\n".join(lines)


def csv_text(headers, rows):
    def escape(value):
        value = text(value)
        # Protect free-text cells when opened in Excel. Numeric cells keep their sign.
        if isinstance(value, text_type) and value.startswith(("=", "+", "@", "-")):
            try:
                float(value)
            except ValueError:
                value = "'" + value
        return '"' + value.replace('"', '""') + '"'
    return "\r\n".join([",".join(escape(v) for v in headers)] +
                         [",".join(escape(v) for v in row) for row in rows]) + "\r\n"


def write_text(path, content, bom=False):
    with io.open(path, "w", encoding="utf-8-sig" if bom else "utf-8", newline="") as stream:
        stream.write(content)


def write_package(model, folder, notes=None):
    # The caller supplies a NEW folder so source files and previous exports stay intact.
    if os.path.exists(folder):
        raise ValueError("Folder hasil sudah ada. Pilih nama folder baru: " + folder)
    os.makedirs(folder)
    try:
        write_text(os.path.join(folder, "model.s2k"), s2k_text(model))
        write_text(os.path.join(folder, "members.csv"), csv_text(HEADERS,
                   [[m.get(h, "") for h in HEADERS] for m in model["members"]]), True)
        write_text(os.path.join(folder, "joints.csv"), csv_text(["Joint", "X_m", "Y_m", "Z_m"],
                   [[i + 1] + list(p) for i, p in enumerate(model["joints"])]), True)
        fields = ["Frame", "JointI", "JointJ", "SourceMember", "Segment"]
        write_text(os.path.join(folder, "frames.csv"), csv_text(fields,
                   [[f[h] for h in fields] for f in model["frames"]]), True)
        report = ["RevitToSAP 0.1.0 | Target SAP2000 v22 | GEOMETRI SAJA",
                  "Members: {} | Joints: {} | Frames: {}".format(
                      len(model["members"]), len(model["joints"]), len(model["frames"])),
                  "Koordinat hasil: meter. Global Z ke atas.",
                  "Toleransi gabung ujung: {} mm".format(fmt(model["tolerance_m"] * 1000)),
                  "Ujung digeser ke joint terdekat: {}. Maksimum: {} mm".format(
                      len(model["snaps"]), fmt(max(model["snaps"] or [0]) * 1000)),
                  "Tambahan potongan pada joint segaris: {}".format(model["split_count"]),
                  "Kelompok geometri yang saling terhubung: {}".format(model["components"]),
                  "Cek profil, material, orientasi sumbu lokal, release, offset, tumpuan,",
                  "beban, kombinasi dan mesh di SAP2000 sebelum analisis.",
                  "Nama profil/material/RotationDeg hanya metadata CSV; tidak di-assign di S2K.",
                  "Persilangan tanpa endpoint/joint tidak dipotong otomatis.",
                  "Revit link, pelat, dinding, bracing, dan member melengkung tidak diekspor."]
        if model["components"] > 1:
            report.append("PERIKSA: ada kelompok yang terpisah; cek sambungan sebelum analisis.")
        report.extend(notes or [])
        write_text(os.path.join(folder, "report.txt"), "\r\n".join(report) + "\r\n")
        manifest = {"schema": 1, "target": "SAP2000 22", "coordinate_units": "m",
                    "geometry_only": True, "members": len(model["members"]),
                    "joints": len(model["joints"]), "frames": len(model["frames"]),
                    "tolerance_m": model["tolerance_m"], "components": model["components"]}
        write_text(os.path.join(folder, "manifest.json"), text(json.dumps(manifest, indent=2)))
    except Exception:
        # Keep any partial export for diagnosis, clearly labelled.
        write_text(os.path.join(folder, "INCOMPLETE.txt"), "Ekspor gagal. Jangan gunakan file di folder ini.")
        raise
