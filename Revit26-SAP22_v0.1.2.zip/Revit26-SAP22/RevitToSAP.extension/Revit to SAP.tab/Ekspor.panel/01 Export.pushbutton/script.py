# -*- coding: utf-8 -*-
__title__ = "Revit ke\nSAP22"
__doc__ = "Ekspor garis analitis balok dan kolom Revit 2026 ke S2K SAP2000 v22 dan CSV."
__min_revit_ver__ = 2026
__max_revit_ver__ = 2026
from r2s.ui import run_export
run_export()
