# -*- coding: utf-8 -*-
__title__ = "Excel CSV\nke SAP22"
__doc__ = "Konversi CSV, TXT, atau XLSX (sheet Members) menjadi S2K SAP2000 v22."
__min_revit_ver__ = 2026
__max_revit_ver__ = 2026
from r2s.ui import run_convert
run_convert()
