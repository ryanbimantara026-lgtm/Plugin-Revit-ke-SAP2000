#!/usr/bin/env python3
"""Optional converter outside Revit. Requires Python 3; no pip packages."""
import argparse
import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                              "RevitToSAP.extension", "lib"))
from r2s.exchange import read_members, build_model, write_package


def main():
    parser = argparse.ArgumentParser(description="CSV/TXT/XLSX balok-kolom ke S2K SAP2000 v22 (geometri)")
    parser.add_argument("input", help="File CSV/TXT atau XLSX dengan sheet Members")
    parser.add_argument("--units", required=True, choices=["m", "mm", "cm", "ft"])
    parser.add_argument("--output", required=True, help="Folder hasil baru; harus belum ada")
    parser.add_argument("--tolerance-mm", type=float, default=1.0)
    parser.add_argument("--no-split", action="store_true", help="Hanya sambungkan ujung")
    args = parser.parse_args()
    try:
        model = build_model(read_members(args.input), args.units, args.tolerance_mm / 1000,
                            split=not args.no_split)
        write_package(model, args.output, ["Sumber: " + os.path.basename(args.input)])
    except (ValueError, OSError, KeyError) as error:
        parser.exit(2, "Gagal: {}\n".format(error))
    print("Selesai: {} member, {} joint, {} frame. {}".format(
        len(model["members"]), len(model["joints"]), len(model["frames"]), args.output))
    return 0


if __name__ == "__main__":
    sys.exit(main())
