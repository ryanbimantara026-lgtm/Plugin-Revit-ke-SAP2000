[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$source = Join-Path $PSScriptRoot 'RevitToSAP.extension'
if (-not (Test-Path -LiteralPath $source -PathType Container)) {
    throw 'Folder RevitToSAP.extension tidak ditemukan. Ekstrak seluruh ZIP dahulu.'
}
$extensions = Join-Path $env:APPDATA 'pyRevit\Extensions'
$destination = Join-Path $extensions 'RevitToSAP.extension'
New-Item -ItemType Directory -Force -Path $extensions | Out-Null
if (Test-Path -LiteralPath $destination) {
    throw "Ekstensi sudah ada: $destination. Cadangkan/pindahkan versi sebelumnya dahulu."
}
Copy-Item -LiteralPath $source -Destination $destination -Recurse
Write-Host "Ekstensi disalin ke: $destination"
Write-Host 'Pasang pyRevit yang mendukung Revit 2026, lalu jalankan ulang Revit.'
Write-Host 'Tab: Revit to SAP. Tombol: Revit ke SAP22 dan Excel CSV ke SAP22.'
